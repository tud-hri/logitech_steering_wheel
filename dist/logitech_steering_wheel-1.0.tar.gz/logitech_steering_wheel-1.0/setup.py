from setuptools import setup

setup(
    name='logitech_steering_wheel',
    version='1.0',
    packages=['logitech_steering_wheel'],
    url='',
    license='',
    author='O. Siebinga',
    author_email='o.siebinga@tudelft.nl',
    description=''
)
